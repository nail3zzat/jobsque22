package com.example.jobsque3

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
