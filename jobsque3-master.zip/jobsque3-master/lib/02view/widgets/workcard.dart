import 'package:flutter/material.dart';

import '../styles/colors.dart';
import '../utilities/resources/assets.dart';

class WorkCard extends StatelessWidget {

  const WorkCard({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(


    );
  }
}
