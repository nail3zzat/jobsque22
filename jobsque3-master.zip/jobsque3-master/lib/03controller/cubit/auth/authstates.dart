class AuthStates{}




class InitialAuthState extends AuthStates{}


class LoginSuccessAuthState extends AuthStates{}
class LoginFailedAuthState extends AuthStates{}


class RegisterSuccessAuthState extends AuthStates{}
class RegisterFailedAuthState extends AuthStates{}


