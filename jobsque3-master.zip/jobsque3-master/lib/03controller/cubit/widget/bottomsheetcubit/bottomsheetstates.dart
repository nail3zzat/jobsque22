class FilterBSStates{}

class InitialFilterBSState extends FilterBSStates{}

class SelectedJobTypeState extends FilterBSStates{}
class UnSelectedJobTypeState extends FilterBSStates{}

