class OnBoardingButtonStates{}




  class InitialOnBoardBState extends OnBoardingButtonStates{}


class FirstOnBoardBState extends OnBoardingButtonStates{}
class SecondOnBoardBState extends OnBoardingButtonStates{}

