

class LocationOfWorkStates{}




class InitialLocationOfWorkState extends LocationOfWorkStates{}


class FirstLocationOfWorkState extends LocationOfWorkStates{}
class SecondLocationOfWorkState extends LocationOfWorkStates{}




