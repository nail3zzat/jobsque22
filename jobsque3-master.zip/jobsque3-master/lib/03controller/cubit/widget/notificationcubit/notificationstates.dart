class NotificationStates{}

class InitialNotificationState extends NotificationStates{}

class ChangeSettingValueState extends NotificationStates{}