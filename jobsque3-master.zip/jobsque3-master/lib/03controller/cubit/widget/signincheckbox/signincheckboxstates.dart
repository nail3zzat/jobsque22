class SignInCheckBoxStates{}




class InitialSignInState extends SignInCheckBoxStates{}


class FirstSignInState extends SignInCheckBoxStates{}
class SecondSignInState extends SignInCheckBoxStates{}

