class SignInButtonStates{}




class InitialSignInButtonState extends SignInButtonStates{}


class FirstSignInButtonState extends SignInButtonStates{}
class SecondSignInButtonState extends SignInButtonStates{}

