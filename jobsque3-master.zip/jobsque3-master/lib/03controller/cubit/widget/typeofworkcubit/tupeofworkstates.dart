

class TypeOfWorkStates{}




class InitialTypeOfWorkState extends TypeOfWorkStates{}


class FirstTypeOfWorkState extends TypeOfWorkStates{}
class SecondTypeOfWorkState extends TypeOfWorkStates{}




